package com.xiaoke.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcUtil {
	public static Connection getMysqlConn() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String link = "jdbc:mysql://localhost:3306/xiaoke?useUnicode=true&characterEncoding=utf8";
			String user = "root";
			String password = "root";
			try {
				conn = DriverManager.getConnection(link,user,password);
				return conn;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static void close(Statement stmt , Connection conn) {
		try {
			if(stmt!=null) {
				stmt.close();
			}
			if(conn!=null) {
				conn.close();
			}
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		   }
	}
	
	public static void close(ResultSet rs , Statement stmt , PreparedStatement ps , Connection conn) {
		try {
			if(rs!=null){
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
			if(ps!=null) {
				ps.close();
			}
			if(conn!=null) {
				conn.close();
			}
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		   }
	}
}
