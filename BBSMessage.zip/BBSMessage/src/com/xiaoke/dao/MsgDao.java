package com.xiaoke.dao;

import java.util.List;
import java.util.Map;

import com.xiaoke.entity.Message;

/**
 * 消息接口
 * @author 小科
 *
 */
public interface MsgDao {
	//添加消息
	public int addMsg(Map<String,Object> map);
	//删除消息
	public int delMsg(Message message);
	//修改消息
	public int updateMsg(Message message);
	//查询消息
	public List<String> msgList(String username);
}
