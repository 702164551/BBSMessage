package com.xiaoke.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.xiaoke.dao.MsgDao;
import com.xiaoke.entity.Message;
import com.xiaoke.util.jdbcUtil;
/**
 * 消息实现类
 * @author 小科
 *
 */
public class MsgDaoImpl implements MsgDao {
	//添加消息
	@Override
	public int addMsg(Map<String,Object> map) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;
		String msgid = (String)map.get("msgid");
		String username = (String)map.get("username");
		String title = (String)map.get("title");
		String content = (String)map.get("content");
		Integer state = (Integer)map.get("state");
		String sendto = (String)map.get("sendto");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String ts = sdf.format(map.get("ts"));
		conn = jdbcUtil.getMysqlConn();
		String sql = "insert into message values(?,?,?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, msgid);
			ps.setString(2, username);
			ps.setString(3, title);
			ps.setString(4, content);
			ps.setInt(5, state);
			ps.setString(6, sendto);
			ps.setString(7, ts);
			int result = ps.executeUpdate();
			if(result > 0) {
				return count = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return count = 0;
		} finally {
			jdbcUtil.close(null, null, ps, conn);
		}
		return count;
	}
	//删除消息
	@Override
	public int delMsg(Message message) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;
		conn = jdbcUtil.getMysqlConn();
		String sql = "delete from message where msgid=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, message.getMsgid());
			boolean flag = ps.execute();
			if(flag) {
				return count=1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return count=0;
		} finally {
			jdbcUtil.close(null, null, ps, conn);
		}
		return count;
	}
	//更新消息
	@Override
	public int updateMsg(Message message) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;
		conn = jdbcUtil.getMysqlConn();
		String sql = "update from mmessagge set title=?,content=? where msg=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, message.getTitle());
			ps.setString(2, message.getContent());
			ps.setString(3, message.getMsgid());
			boolean flag = ps.execute();
			if(flag) {
				return count=1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return count=0;
		} finally {
			jdbcUtil.close(null, null, ps, conn);
		}
		return count;
	}
	//查询消息
	@Override
	public List<String> msgList(String username) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		List<String> list = new ArrayList<>();
		conn = jdbcUtil.getMysqlConn();
		String sql = "select title,content,username,sendto,datetime from message where username="+username;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				list.add(rs.getString(1));
				list.add(rs.getString(2));
				list.add(rs.getString(3));
				list.add(rs.getString(4));
				list.add(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
//	public static void main(String[] args) {
//		MsgDaoImpl msgDao = new MsgDaoImpl();
//		List<String> list = msgDao.msgList("123");
//		for(String msg:list) {
//			System.out.println(msg);
//		}
//	}

}
