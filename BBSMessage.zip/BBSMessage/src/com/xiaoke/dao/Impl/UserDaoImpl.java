package com.xiaoke.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.xiaoke.dao.UserDao;
import com.xiaoke.entity.User;
import com.xiaoke.util.jdbcUtil;
/**
 * 用户接口实现类
 * @author 小科
 *
 */
public class UserDaoImpl implements UserDao {
	
	 
	/**
	 * 添加用户
	 */
	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;
		conn = jdbcUtil.getMysqlConn();
		String sql = "insert into User values(?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmail());
			int result = ps.executeUpdate();
			if(result > 0) {
				return count = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return count = 0;
		} finally {
			jdbcUtil.close(null, null, ps, conn);
		}
		return count;		
	}
	
	/**
	 * 删除用户
	 */
	@Override
	public int delUser(User user) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;
		conn = jdbcUtil.getMysqlConn();
		String sql = "delete from User where username=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			int result = ps.executeUpdate();
			if(result > 0) {
				return count = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return count = 0;
		}
		return count;
	}
	/**
	 * 查询用户
	 */
	@Override
	public int queUser(User user) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int result = 0;
		conn = jdbcUtil.getMysqlConn();
		try {

			String sql="select count(*) from user where username=? and password=?";
			 ps=conn.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			 rs = ps.executeQuery();
			while(rs.next()) {
				result = rs.getInt(1);
			}
			if(result > 0) {
				return result;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		} finally {
			jdbcUtil.close(rs, null, ps, conn);
		}
		return result;
	}
	/**
	 * 更新用户
	 */
	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;
		conn = jdbcUtil.getMysqlConn();
		String sql = "update from User set password = ? where username=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getPassword());
			ps.setString(2, user.getUsername());
			int result = ps.executeUpdate(sql);
			if(result > 0) {
				return count = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return count = 0;
		} finally {
			jdbcUtil.close(rs, null, ps, conn);
		}
		return count;
	}
	/**
	 * 查询所有用户
	 */
	@Override
	public List<String> queUserList() {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<String> list = new ArrayList<>();
		conn = jdbcUtil.getMysqlConn();
		String sql = "select username from user where 1=1"; 
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				//user.setUsername(rs.getString(1));
				list.add(rs.getString(1));
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
}
