package com.xiaoke.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 数据库工具类
 * @author 小科
 *
 */
public class BaseDao {
	private final static String DRIVER = "com.mysql.jdbc.Driver";	//加载驱动
	private final static String DBNAME = "root"; 					//数据库用户名
	private final static String DBPASSWORD = "root";				//数据库密码
	private final static String URL = "jdbc:mysql://localhost:3306/xiaoke?useUnicode=true&characterEncoding=utf8";
	protected Connection conn = null;
	protected PreparedStatement ps = null;
	protected ResultSet rs = null;
	//连接数据库
	public void openConnection() {
		try {
			Class.forName(DRIVER);
			try {
				conn = DriverManager.getConnection(URL,DBNAME,DBPASSWORD);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//关闭数据库
	protected void close(){		
		try {
			if(rs != null)
				rs.close();
			if(ps != null)
				ps.close();
			if(conn != null)
				conn.close();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
}
