package com.xiaoke.dao;
/**
 * 用户接口
 * @author 小科
 *
 */

import java.util.List;

import com.xiaoke.entity.User;

public interface UserDao {
	//增加用户
	public int  addUser(User user);
	//删除用户
	public int  delUser(User user);
	//查询用户
	public int  queUser(User user);
	//修改用户
	public int  updateUser(User user);
	//查询所有用户
	public List<String> queUserList();
	
}
