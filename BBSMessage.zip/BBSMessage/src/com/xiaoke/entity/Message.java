package com.xiaoke.entity;

import java.sql.Date;

/**
 * 消息实体类
 * @author 小科
 *
 */
public class Message {
	
	private String msgid;
	private String username;
	private String title;
	private String content;
	private int state = 0;
	private String sendto;
	private Date datetime;
	
	public Message() {
		super();
	}

	public Message(String msgid, String username, String title, String content, int state, String sendto,
			Date datetime) {
		super();
		this.msgid = msgid;
		this.username = username;
		this.title = title;
		this.content = content;
		this.state = state;
		this.sendto = sendto;
		this.datetime = datetime;
	}

	public String getMsgid() {
		return msgid;
	}

	public void setMsgid(String msgid) {
		this.msgid = msgid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getSendto() {
		return sendto;
	}

	public void setSendto(String sendto) {
		this.sendto = sendto;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date ts) {
		this.datetime = ts;
	} 	
	
}
