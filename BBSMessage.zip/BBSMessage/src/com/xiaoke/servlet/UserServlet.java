package com.xiaoke.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.xiaoke.dao.UserDao;
import com.xiaoke.dao.Impl.UserDaoImpl;
import com.xiaoke.entity.User;
/**
 * 用户处理
 * @author 小科
 *
 */
public class UserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		UserDao userDao = new UserDaoImpl();
		User user = new User();
		if("login".equals(action)) {	//登录
			String username = request.getParameter("username").trim();
			String password = request.getParameter("password").trim();
			user.setUsername(username);
			user.setPassword(password);
			int result = userDao.queUser(user);
			if(result > 0) {  //登录成功
				request.getSession().setAttribute("loginuser", username);
				response.sendRedirect("MsgServlet?action=list");
			} else {	//登录失败
				request.setAttribute("error", "账号或密码错误");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			
		} else if("register".equals(action)) {	//注册
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			user.setUsername(username);
			user.setPassword(password);
			user.setEmail(email);
			
			int result = userDao.addUser(user);
			if(result > 0) {	//注册成功
				request.setAttribute("error", "注册成功");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			} else {
				request.setAttribute("error", "此用户已被注册");
		  		request.getRequestDispatcher("register.jsp").forward(request, response);
			}
		} else if("loginout".equals(action)) {	//退出
			request.getSession().removeAttribute("loginuser");
			response.sendRedirect("index.jsp");
		} else if("findUser".equals(action)) {	//查找用户集
			//得到当前用户
			//String username = (String)request.getSession().getAttribute("loginuser");
			List<String> list = userDao.queUserList();
			request.getSession().setAttribute("users", list);
			request.getRequestDispatcher("newMsg.jsp").forward(request, response);
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
