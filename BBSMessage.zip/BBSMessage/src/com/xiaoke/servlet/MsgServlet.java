package com.xiaoke.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.xiaoke.dao.Impl.MsgDaoImpl;
/**
 * 消息处理
 * @author 小科
 *
 */

public class MsgServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		MsgDaoImpl msgDao = new MsgDaoImpl();
		if("del".equals(action)) {	//删除短信息
			
		} else if("send".equals(action)) {	//发送短信息
			Random r = new Random();
			String msgid = String.valueOf(r.nextInt());
			String username = (String)request.getSession().getAttribute("loginuser");
			String toUser = request.getParameter("toUser");
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			int state = 0;
			Date ts = new Date();
			Map <String,Object> map = new HashMap<String,Object>();	
			map.put("msgid", msgid);
			map.put("sendto", toUser);
			map.put("title", title);
			map.put("content", content);
			map.put("state", state);
			map.put("username", username);
			map.put("ts", ts);
			int result = msgDao.addMsg(map);
			if(result > 0) {	//发送消息成功
				response.sendRedirect("MsgServlet?action=list");
			}		
		} else if("list".equals(action)) {	//显示短消息
			//得到当前用户
			String username = (String)request.getSession().getAttribute("loginuser");
			List<String> contents = msgDao.msgList(username);
			request.getSession().setAttribute("contents", contents);
			request.getRequestDispatcher("main.jsp").forward(request, response);
		} else if("read".equals(action)) {	//读取短信息
			
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
